/*
 * life.h
 * 
 * Author: ZHONGYANG ZHENG.
 */

#ifndef LIFE_H_
#define LIFE_H_

#include <stdint.h>
void init_life(void);
void lose_life(void);
uint8_t get_life(void);
void display_life(void);
#endif /* LIFE_H_ */