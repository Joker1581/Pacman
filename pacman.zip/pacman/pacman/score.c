/*
 * score.c
 *
 * Written by Peter Sutton. Modified by <ZHONGYANG ZHENG>
 */
#include <stdio.h>
#include "score.h"
#include "terminalio.h"
#include "game.h"
uint32_t score;
uint32_t high_score = 0;

void init_score(void) {
	score = 0;
}

void add_to_score(uint16_t value) {
	score += value;
}

uint32_t get_score(void) {
	return score;
}

void print_scores(void){
	add_to_score(10);
	if (high_score<=score)
	{
		high_score = score;
	}
	move_cursor(35,18);
	printf("Score");
	move_cursor(35,20);
	printf("%lu", score);
	move_cursor(35,22);
	printf("High Score");
	move_cursor(35,24);
	printf("%lu", high_score);
}






