/*
 * life.c
 *
 * Written by ZHONGYANG ZHENG.
 */
#include <stdio.h>
#include "life.h"
#include "game.h"
#include "terminalio.h"
#include <avr/io.h>
#include <avr/interrupt.h>
uint8_t life = 0;
uint8_t max_life = 3;
uint8_t led_num = 0xFF;
uint8_t init_led_num = 0x07;
extern uint8_t game_running;
void init_life(void){
	life = max_life;
	PORTA = init_led_num;
}
void lose_life(void){
	if(life>1){
		life --;
	}
	else{
		led_num = 0xF8;
		PORTA &= led_num;
		game_running = 0;
	}
	if (life == 2)
	{
		led_num = 0xFB;
	} 
	else if(life == 1)
	{
		led_num = 0xF9;
	}
	
	PORTA &= led_num;
}
uint8_t get_life(void){
	return life;
}
void display_life(void){
	move_cursor(35,26);
	printf("%u",life);
}